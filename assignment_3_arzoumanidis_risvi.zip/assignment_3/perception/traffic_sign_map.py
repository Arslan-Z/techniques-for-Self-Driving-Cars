from typing import Tuple, Dict, List, Union
import numpy as np

from perception.utils import CATEGORIES, transform_to_numpy, TrafficSign


class TrafficSignMap:
    """ Integrate detection into a 2D map representation that records the location of traffic signs.


    """

    def __init__(self):

        self._map: List[TrafficSign] = []
        # Idee ist: erstelle eine List nur mit den 5 vorhandenen Zeichen
        # -> Update diese indem die confidenz immer aufaddiert wird und
        # druch zwei dividiert wird

        self.x_k = TrafficSign()
        self.x_k_1 = TrafficSign()

    def update_map(self, position: Union[np.array, Tuple[float, float]], sign_type: str, confidence: float):
        """ Integrate given type at the specificed 2d world position.

            We have to account for the confidence values and the position of the traffic sign.

            Args:
              position: two-dimensional world position of the traffic sign, i.e., (x,y)-point in UE coordinate system (x-forward, y-right, z-up)
              sign_type: type of sign from CATEGORIES.
              confidences: confidence value from the detection approach.
        """
        assert (sign_type in CATEGORIES)
        if isinstance(position, (tuple, list)):
            position = np.array(position)

        traffic_sign = self.get_closest_sign(position, 5)
        # or traffic_sign not in self._map
        sqr_closest_distance = 5 * 5
        sqr_distance = np.dot(position - self.x_k.position,
                              position - self.x_k.position)

        #traffic_sign not in self._map

        if traffic_sign not in self._map:
            if np.max(self.x_k_1.distribution) <= 0.95:
                print(np.max(self.x_k_1.distribution))
                self.x_k_1 = self.x_k
                self.x_k = TrafficSign(position, sign_type, confidence)

                belief_new = self.x_k_1.distribution * self.x_k.distribution
                ita = 1/np.sum(belief_new)
                belief_new = ita * np.array(belief_new)

                self.x_k.distribution = belief_new

                # print(belief_new)
            else:
                self._map.append(self.x_k)
                self.x_k = TrafficSign()
                self.x_k_1 = TrafficSign()

        print(len(self._map))

    # Wir wollen es so machen, dass wir fuer jedes Schild nur eine confidence erhalten

    # print(len(self._map))
    # confidence, category und traffic signs verbinden
    # print(confidence)

    # print(sign_type)
    # print(position)

    # mit confidence und position die traffic signs in die list richtig einsortieren (logic)
    # print(traffic_sign.position)

    # Update the postion of the traffic sign
    # traffic_sign = self.get_closest_sign(position, 0.2)

    # if ( threshold = exceeded || confidence = reached)

    # Update the sign type of the traffic sign
    # traffic_sign.category = sign_type

    # Update distribution of the traffic sign
    # new_distribution = np.array(
    #     [(1 - confidence) / (len(CATEGORIES) - 1)] * len(CATEGORIES))
    # if sign_type in CATEGORIES:
    #     new_distribution[CATEGORIES.index(sign_type)] = confidence

    # if self._map[CATEGORIES.index(sign_type)] == None:
    #     traffic_sign.distribution = new_distribution
    #     self._map.append(traffic_sign)
    # else:
    #     old_distribution = self._map[CATEGORIES.index(
    #         sign_type)].distribution
    #     updated_distribution = (old_distribution + new_distribution) / 2
    #     traffic_sign.distribution = updated_distribution
    #     self._map[CATEGORIES.index(sign_type)] = traffic_sign

    # for element in range(0, 5):
    #     print(self._map[element].distribution)

    ############################################ TASK 3 ############################################
    # TODO: add logic to update the map with with 2D location. Initialize traffic sign location if needed.

    # print(traffic_sign.category)
    # print("----------------------")
    # print(traffic_sign.distribution)
    # print("----------------------")
    # print(traffic_sign.position)
    # print("----------------------")

    # else:
    #     for sign in self._map:
    #         if sign.position == new_traffic_sign.position:
    #             print("-")
    # traffic_sign_set = set(self._map)
    # traffic_sign_set_update = traffic_sign_set.union(new_traffic_sign)

    def get_closest_sign(self, position: Union[np.array, Tuple[float, float]], max_distance: float = 5.0) -> TrafficSign:
        """ gets closest traffic sign to a given position within a specific radius.

          Args:
            position: query position.
            max_distance: maximal distance of traffic sign for query.

          Return:
            closest traffic sign or TrafficSign with default values, i.e., category = "none"
        """
        if isinstance(position, (tuple, list)):
            position = np.array(position)

        sqr_closest_distance = max_distance * max_distance
        result = TrafficSign()

        # one could use proper neighbor search, like a quad tree, but this should work for small examples:
        for entry in self._map:
            sqr_distance = np.dot(position - entry.position,
                                  position - entry.position)
            if sqr_distance < sqr_closest_distance:
                sqr_closest_distance = sqr_distance
                result = entry

        return result

    def get_traffic_signs(self):
        """ get list of traffic signs represented in the map. """
        return self._map
