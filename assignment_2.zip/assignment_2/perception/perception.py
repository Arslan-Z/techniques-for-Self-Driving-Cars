import sys
from sdc import World
from typing import List
import numpy as np
from math import sqrt
import carla


class Perception:
    """ Perception module providing information about
    - parked cars using information from the world.
    - traffic signs using a vision-based detector.
  """

    def __init__(self, world: World):
        self._detector = None
        self._world = world
        self.max_distance = 25

    def detect_parked_cars(
        self, max_distance: float = 20.0, field_of_view: float = 90.0
    ) -> List[carla.Location]:
        """
      Determine parked cars around the vehicle.

      It's a work around that uses the known poses of spawned parked cars to determine which parked cars are nearby.
    """
        parked_cars = self._world.get_parked_cars()
        cars = []

        car_pose = self._world.get_vehicle().get_transform()
        for parked_car in parked_cars:
            vec_car2parked = np.array(
                [
                    parked_car.location.x - car_pose.location.x,
                    parked_car.location.y - car_pose.location.y,
                ]
            )
            distance2parked = sqrt(np.dot(vec_car2parked, vec_car2parked))

            if distance2parked < max_distance:
                cars.append(parked_car.location)

        return cars
