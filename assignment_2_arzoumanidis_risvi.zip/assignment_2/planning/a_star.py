from sdc.utility import waypoint_distance
from .graph import Graph
import math


def a_star_search(graph: Graph, node_to_xy, start: int, end: int):
    """
    Returns shortest path as a list of nodes ids.

    : param graph : graph definition.
    : param node_to_xy : mapping of nodes to x and y positions.
    : param start : id of the start node.
    : param end : id of the end/target node.
    """
    open_list = [start]  # List of nodes that have not been visited yet
    closed_list = []  # List of nodes that have been visited
    came_from = {start: None}  # Keep track of best predecessor of each node
    # Keep track of each node and its accumulated cost
    accumulated_cost = {start: 0}
    # Keep track of each node and its estimated cost
    estimated_cost = {start: 0}
    path = []
    #####################################################################################
    ##################    Task 2: Implement the A* algorithm here      ##################
    #####################################################################################

    end_coordiantes = node_to_xy[end]

    while len(open_list) != 0:

        best = 10000
        best_key = 10000
        for item in open_list:
            curr = accumulated_cost[item]
            if curr < best:
                best = curr
                best_key = item

        closed_list.append(best_key)
        open_list.remove(best_key)

        if(end != best_key):
            for child in graph.get_children(best_key):
                if child not in closed_list:
                    if child not in open_list:
                        open_list.append(child)

                        # Update des Gewichtes der Kinder
                        accumulated_cost[child] = graph.get_cost(
                            best_key, child) + best
                        # Update von wo die Kinder in dieser Iteration erreicht wurden
                        came_from[child] = best_key
                        estimated_cost[child] = waypoint_distance(
                            end_coordiantes, node_to_xy[child])

                    else:
                        # estimated cost fehlt hier noch - ist es mit einer liste vom start node zu jedem anderen node?
                        temp_child_cost_acc = graph.get_cost(
                            best_key, child) + best
                        temp_child_cost_est = waypoint_distance(
                            end_coordiantes, node_to_xy[child])
                        temp_child_cost = temp_child_cost_est + temp_child_cost_acc

                        if temp_child_cost < (accumulated_cost[child] + temp_child_cost_est):
                            accumulated_cost[child] = temp_child_cost_acc
                            estimated_cost[child] = temp_child_cost_est
                            came_from[child] = best_key

        else:
            temp = end
            while temp != None:
                path.append(temp)
                temp = came_from[temp]

    path.reverse()

    return path
