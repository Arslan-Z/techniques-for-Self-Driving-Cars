# Copyright (c) # Copyright (c) 2018-2020 CVC.
# This work is licensed under the terms of the MIT license.
# For a copy, see <https://opensource.org/licenses/MIT>.

from collections import deque
from typing import Union
import math
from sdc.car import Car
import numpy as np
import carla
from sdc.utility import *

from pyilqr.pyilqr.costs import CompositeCost, QuadraticCost
from pyilqr.pyilqr.example_costs import SetpointTrackingCost, PolylineTrackingCost, Polyline
from pyilqr.pyilqr.example_dynamics import UnicycleDynamics
from pyilqr.pyilqr.ocp import OptimalControlProblem
from pyilqr.pyilqr.ilqr import ILQRSolver
from pyilqr.pyilqr.strategies import AbstractStrategy, OpenLoopStrategy, FunctionStrategy
from pyilqr.pyilqr.receding_horizon import RecedingHorizonStrategy


class AbstractController:
    """
    Controller Class
    """

    def __init__(self, vehicle: Car, params):
        """
        Constructor method.
        :param vehicle: actor to apply to local planner logic onto
        :param params: All the controller related parameters
        """

        self.max_brake = params["control"]["max_brake"]
        self.max_throttle = params["control"]["max_throttle"]
        self.max_steer = params["control"]["max_steering"]
        self.L = params["model"]["L"]
        self.dt = params["sampling_time"]

        self._vehicle = vehicle
        self.past_steering = self._vehicle.get_control().steer

    def compute_control(self, target_velocity_kmph, waypoints):
        """
        Computes one step of control
        :param target_velocity_kmph: desired vehicle velocity in kmph
        :param waypoints: local trajectory waypoints
        :return: control command for the vehicle.
        """
        # target waypoint reached.
        if len(waypoints) < 4:
            return carla.VehicleControl(0, 0, brake=1.0)

        target_velocity_ms = target_velocity_kmph / 3.6

        current_steering, acceleration = self.compute_steering_and_acceleration(
            target_velocity_ms, waypoints
        )

        # Set limits
        control = carla.VehicleControl()
        print(acceleration)
        if acceleration >= 0.0:
            control.throttle = min(acceleration, self.max_throttle)
            control.brake = 0.0
        else:
            control.throttle = 0.0
            control.brake = min(abs(acceleration), self.max_brake)

        if current_steering >= 0:
            steering = min(self.max_steer, current_steering)
        else:
            steering = max(-self.max_steer, current_steering)

        control.steer = steering
        control.hand_brake = False
        control.manual_gear_shift = False
        self.past_steering = steering

        return control

    def compute_steering_and_acceleration(self, target_velocity_ms, waypoints):
        raise NotImplementedError("Controller is not specified!")


class DecomposedController(AbstractController):
    """
    DecomposedController is the combination of two controllers
    (lateral and longitudinal) to perform the low level control a vehicle from client side.
    The longitudinal control is a PID controller, whereas the lateral controller can be
    chosen from a PID controller, Pure Pursuit Contoller or a Stanley Controller.
    """

    def __init__(self, vehicle: Car, params):
        """
        Constructor method.
        :param vehicle: actor to apply to local planner logic onto
        :param params: All the controller related parameters
        """
        super().__init__(vehicle, params)

        # Longitudinal
        args_longitudinal = params["control"]["longitudinal"]["pid"]
        self._lon_controller = PIDLongitudinalController(
            self._vehicle, self.dt, **args_longitudinal
        )

        # Lateral
        lateral_strategy = params["control"]["strategy"]
        args_lateral = params["control"]["lateral"][lateral_strategy]
        if lateral_strategy == "stanley":
            self._lat_controller = StanleyLateralController(
                self._vehicle, **args_lateral
            )
        elif lateral_strategy == "pure-pursuit":
            self._lat_controller = PurePursuitLateralController(
                self._vehicle, self.L, **args_lateral
            )
        else:
            self._lat_controller = PIDLateralController(
                self._vehicle, self.dt, **args_lateral
            )

    def compute_steering_and_acceleration(self, target_velocity_ms, waypoints):
        """
        Computes one step of control invoking both lateral and longitudinal
        :param target_velocity_ms: desired vehicle velocity in m/s
        :param waypoints: local trajectory waypoints
        :return: control command for the vehicle.
        """
        current_steering = self._lat_controller.run_step(waypoints)
        acceleration = self._lon_controller.run_step(target_velocity_ms)

        # Steering regulation: changes cannot happen abruptly, can't steer too much.
        if current_steering > self.past_steering + 0.1:
            current_steering = self.past_steering + 0.1
        elif current_steering < self.past_steering - 0.1:
            current_steering = self.past_steering - 0.1
        return current_steering, acceleration


class PIDLongitudinalController:
    """
    PIDLongitudinalController implements longitudinal control using a PID.
    """

    def __init__(self, vehicle, dt, K_P, K_D, K_I):
        """
      Constructor method.

          :param vehicle: actor to apply to local planner logic onto
          :param dt: time differential in seconds
          :param K_P: Proportional term
          :param K_D: Differential term
          :param K_I: Integral term
      """

        self._vehicle = vehicle
        self._dt = dt
        self._k_p = K_P
        self._k_d = K_D
        self._k_i = K_I
        self._error_buffer = deque(maxlen=10)
        self._error_buffer.append(0)

    def run_step(self, target_velocity_ms, debug=False):
        """
    Execute one step of longitudinal control to reach a given target velocity.

        :param target_velocity_ms: target velocity in m/s
        :param debug: boolean for debugging
        :return: throttle control
    """
        current_velocity_ms = get_velocity_ms(self._vehicle)

        if debug:
            print("Current velocity = {}".format(current_velocity_ms))

        return self._pid_control(target_velocity_ms, current_velocity_ms)

    def _pid_control(self, target_velocity_ms, current_velocity_ms):
        """
        Estimate the throttle/brake of the vehicle based on the PID equations

            :param target_velocity_ms:  target velocity in m/s
            :param current_velocity_ms: current velocity of the vehicle in m/s
            :return: throttle/brake control
        """
        #######################################################################
        ################## TODO: IMPLEMENT LONGITUDINAL PID CONTROL HERE ######
        #######################################################################
        current_error = target_velocity_ms - current_velocity_ms
        # update error buffer
        # Once a bounded length deque is full, when new items are added, a
        # corresponding number of items are discarded from the opposite end.
        # add to right side of queue
        self._error_buffer.append(current_error)

        # if(len(self._error_buffer) < 2):
        #   self._error_buffer.appendleft(0)

        diff_error = (self._error_buffer[-2]-self._error_buffer[-1])

        u_acc = self._k_p * (current_error)
        + self._k_d * (diff_error / self._dt)
        + self._k_i * np.sum(self._error_buffer)
        # print(np.sum(self._error_buffer))
        return u_acc


class PIDLateralController:
    """
    PIDLateralController implements lateral control using a PID.
    """

    def __init__(self, vehicle, dt, K_P, K_D, K_I):
        """
        Constructor method.

            :param vehicle: actor to apply to local planner logic onto
            :param dt: time differential in seconds
            :param K_P: Proportional term
            :param K_D: Differential term
            :param K_I: Integral term
        """
        self._vehicle = vehicle
        self._dt = dt
        self._k_p = K_P
        self._k_d = K_D
        self._k_i = K_I
        self._e_buffer = deque(maxlen=10)
        self._e_buffer.append(0)

    def run_step(self, waypoints):
        """
        Execute one step of lateral control to steer
        the vehicle towards a certain waypoin.

            :param waypoint: target waypoint
            :return: steering control in the range [-1, 1] where:
            -1 maximum steering to left
            +1 maximum steering to right
        """
        return self._pid_control(waypoints, self._vehicle.get_transform())

        # carla gives in degress but we need radians
        # rad. to pi
    def _get_heading_error(self, waypoints, vehicle_yaw):
        """

        """
        waypoint_delta_x = waypoints[1][0] - waypoints[0][0]
        waypoint_delta_y = waypoints[1][1] - waypoints[0][1]
        waypoint_heading = np.arctan2(waypoint_delta_y, waypoint_delta_x)
        heading_error_mod = divmod((waypoint_heading - vehicle_yaw), np.pi)[1]
        if heading_error_mod > np.pi / 2 and heading_error_mod < np.pi:
            heading_error_mod -= np.pi
        return heading_error_mod

    def _get_steering_direction(self, v1, v2):
        """
        Provides steering direction given the current vehicle direction and vector towards ...

        """
        cross_prod = v1[0] * v2[1] - v1[1] * v2[0]
        if cross_prod >= 0:
            return -1
        return 1

    def _pid_control(self, waypoints, vehicle_transform):
        """
        Estimate the steering angle of the vehicle based on the PID equations

            :param waypoints: local waypoints
            :param vehicle_transform: current transform of the vehicle
            :return: steering control in the range [-1, 1]
        """
        #######################################################################
        ################## TODO: IMPLEMENT LATERAL PID CONTROL HERE ###########
        #######################################################################

        # calculate cross track error
        nearest_waypoint, ind_nearest = get_nearest_waypoint(
            self._vehicle, waypoints)
        e_cte = compute_distance_to_waypoint(self._vehicle, nearest_waypoint)

        yaw_radians = vehicle_transform.rotation.yaw * np.pi/180

        regulate_yaw = wrapToPi(self, yaw_radians)

        # print(np.shape(nearest_waypoint))
        # add cross track error - and heading error

        h_cte = self._get_heading_error(waypoints, regulate_yaw)

        e_cte = e_cte + h_cte

        # update error buffer
        # Once a bounded length deque is full, when new items are added, a
        # corresponding number of items are discarded from the opposite end.
        # add to right side of queue
        self._e_buffer.append(e_cte)

        # if(len(self._e_buffer) < 2):
        #   self._e_buffer.appendleft(0)

        diff_error = (self._e_buffer[-2]-self._e_buffer[-1])

        u_steer = -self._k_p * e_cte
        - self._k_d * (diff_error / self._dt)
        - self._k_i * np.sum(self._e_buffer)

        # print(self._e_buffer)
        # print(nearest_waypoint[0][0:2])
        from math import sin, cos

        diff_vector = (nearest_waypoint[0] - vehicle_transform.location.x,
                       nearest_waypoint[1] - vehicle_transform.location.y)
        direction = self._get_steering_direction(
            (cos(regulate_yaw), sin(regulate_yaw)), diff_vector)

        if(u_steer > 1):
            u_steer = 1
        elif(u_steer < -1):
            u_steer = -1
        print(u_steer, direction)

        return direction * u_steer


class StanleyLateralController:
    """
      StanleyLateralController implements lateral control using the stanley controller.
    """

    def __init__(self, vehicle, K_cte):
        self._vehicle = vehicle
        # K ist das gain für den (e)cte
        self._k_cte = K_cte

    def run_step(self, waypoints):
        return self._stanley_control(waypoints, self._vehicle.get_transform())

    def _get_heading_error(self, waypoints, vehicle_yaw):
        waypoint_delta_x = waypoints[1][0] - waypoints[0][0]
        waypoint_delta_y = waypoints[1][1] - waypoints[0][1]
        waypoint_heading = np.arctan2(waypoint_delta_y, waypoint_delta_x)
        heading_error_mod = divmod((waypoint_heading - vehicle_yaw), np.pi)[1]
        if heading_error_mod > np.pi / 2 and heading_error_mod < np.pi:
            heading_error_mod -= np.pi
        return heading_error_mod

    def _get_steering_direction(self, v1, v2):
        cross_prod = v1[0] * v2[1] - v1[1] * v2[0]
        if cross_prod >= 0:
            return -1
        return 1

    def _get_cte_heading_error(self, vel, waypoints):
        nearest_waypoint, ind_nearest = get_nearest_waypoint(
            self._vehicle, waypoints)
        nearest_distance = compute_distance_to_waypoint(
            self._vehicle, nearest_waypoint)
        proportional_cte_error = self._k_cte * nearest_distance
        cte_heading_error = np.arctan2(proportional_cte_error, vel)
        cte_heading_error_mod = divmod(cte_heading_error, np.pi)[1]
        if cte_heading_error_mod > np.pi / 2 and cte_heading_error_mod < np.pi:
            cte_heading_error_mod -= np.pi
        return cte_heading_error_mod

    def _stanley_control(self, waypoints, vehicle_transform):
        """
        :param waypoint: list of waypoints
        :param vehicle_transform: current transform of the vehicle
        :return: steering control in the range [-1, 1]
        """
        #######################################################################
        ################## TODO: IMPLEMENT STANLEY CONTROL HERE ###############
        #######################################################################

        # Align Heading (differnece of the current heading and the orientation
        # of the nearest point in the trajectory)
        yaw_radians = vehicle_transform.rotation.yaw * np.pi/180
        regulate_yaw = wrapToPi(self, yaw_radians)
        h_cte = self._get_heading_error(waypoints, regulate_yaw)

        # Cross-track error
        current_velocity_ms = get_velocity_ms(self._vehicle)
        e_cte = self._get_cte_heading_error(current_velocity_ms, waypoints)
        delta_steering = h_cte + \
            np.arctan(((self._k_cte * e_cte) / current_velocity_ms))

        # Setup steering limit
        if(delta_steering > 1):
            delta_steering = 1
        elif(delta_steering < -1):
            delta_steering = -1

        return delta_steering


class PurePursuitLateralController:
    def __init__(self, vehicle, L, ld, K_pp):
        self._vehicle = vehicle
        self._L = L
        self._ld = ld
        self._k_pp = K_pp

    def run_step(self, waypoints):
        return self._pure_pursuit_control(waypoints, self._vehicle.get_transform())

    def _get_goal_waypoint_index(self, vehicle, waypoints, lookahead_dist):
        for i in range(len(waypoints)):
            dist = compute_distance_to_waypoint(vehicle, waypoints[i])
            if dist >= lookahead_dist:
                return max(0, i)
        return len(waypoints) - 1

    def _get_steering_direction(self, v1, v2):
        cross_prod = v1[0] * v2[1] - v1[1] * v2[0]
        if cross_prod >= 0:
            return -1
        return 1

    def _pure_pursuit_control(self, waypoints, vehicle_transform):
        """
        :param waypoints: list of waypoints
        :param vehicle_transform: current transform of the vehicle
        :return: steering control in the range [-1, 1]
        """
        #######################################################################
        ################## TODO: IMPLEMENT PURE-PURSUIT CONTROL HERE ##########
        #######################################################################
        return 0.0


class ModelPredictiveController(AbstractController):
    """
    Receding horizon controller using an iterative LQR solver. At each iteration, the nonlinear optimal control problem is solved with local linear-quadratic approximations.
    """

    def __init__(self, vehicle: Car, params):
        """
        Constructor method.
        :param vehicle: actor to apply to local planner logic onto
        :param params: All the controller related parameters
        """
        super().__init__(vehicle, params)
        self.dynamics = UnicycleDynamics(self.dt)
        self.prediction_horizon = 20
        self._initial_strategy = None
        self.reset_initial_strategy(self._initial_strategy)
        self.vehicle = vehicle

    def reset_initial_strategy(self, initial_strategy: Union[AbstractStrategy, None]):
        if initial_strategy is None:
            initial_strategy = FunctionStrategy(
                lambda x, t: np.zeros(self.dynamics.dims[1])
            )
        object.__setattr__(self, "_initial_strategy", initial_strategy)

    def _get_steering_direction(self, v1, v2):
        """
        Provides steering direction given the current vehicle direction and vector towards ...

        """
        cross_prod = v1[0] * v2[1] - v1[1] * v2[0]
        if cross_prod >= 0:
            return -1
        return 1

    def compute_steering_and_acceleration(self, target_velocity_ms, waypoints):
        """
        Computes steering and acceleration
        :param target_velocity_ms: desired vehicle velocity in m/s
        :param waypoints: local trajectory waypoints
        :return: control command for the vehicle.
        """

        #######################################################################
        ################## TODO: IMPLEMENT MPC CONTROL HERE ###################
        #######################################################################

        # state layout `x = px, py, phi, v`
        px = self.vehicle.get_transform().location.x
        py = self.vehicle.get_transform().location.y

        # orientation of the vehicle in rad
        phi = self.vehicle.get_transform().rotation.yaw * np.pi/180
        v = get_velocity_ms(self.vehicle)

        x_curr = np.array([px, py, phi, v])

        # current inputs u -> current steering angle and acceleration
        #steering = self.vehicle.get_control().steer

        #acceleration = target_velocity_ms - v

        #u = np.array([steering, acceleration])

        #nearest_waypoint, ind_nearest = get_nearest_waypoint(self._vehicle,waypoints)

        #x_des = np.array([nearest_waypoint[0], nearest_waypoint[1], phi+steering, target_velocity_ms])

        # calculate current state/input costs
        state_cost = SetpointTrackingCost(np.eye(4), x_curr)
        input_cost = QuadraticCost(np.eye(2), np.zeros(2))

        # problem definition
        ocp = OptimalControlProblem(self.dynamics, state_cost, input_cost,
                                    self.prediction_horizon)

        # solve ILQR
        ilqr = ILQRSolver(ocp)

        #diff = 1  # updated_cost - last_cost
        #while not diff > 0.1:
            #x0 = x
        #initial_strategy = OpenLoopStrategy(u)
        #last_xop, last_uop, last_cost = ilqr.solve(x_des, initial_strategy)

        # step size alpha is adjusted inside _update_operating_point
        #updated_xop, updated_uop, updated_cost, found_decent_step = ilqr._update_operating_point(
         #   last_xop, last_uop, last_cost, n_backtracking_steps=10)
        #diff = updated_cost - last_cost
        #x = updated_xop
        #u = updated_uop

        receding_horizon_strategy = RecedingHorizonStrategy(ilqr)
        xs, us, info = self.dynamics.rollout(x_curr, receding_horizon_strategy, 100)
        

        #initial_strategy = FunctionStrategy(lambda x, t: u)
        #initial_xs, initial_us, _ = self.dynamics.rollout(x_des, initial_strategy, self.prediction_horizon)
        #initial_cost = state_cost.trajectory_cost(initial_xs) + input_cost.trajectory_cost(initial_us)

        #xs, us, has_converged = ilqr.solve(x_des, initial_strategy)

        #assert info
        #assert (
        #    state_cost.trajectory_cost(xs) + input_cost.trajectory_cost(us) < 0
        #)

        steering = us[0]
        acceleration = us[1]

        return steering
