from typing import Dict
import numpy as np
from sdc.utility import load_waypoints_from_txt

class FixedGlobalPlanner:
    """ 
  Fixed global planner reads waypoints from a file that was precomputed/recorded in advance.
  """

    def __init__(self, params: Dict):
        self._waypoints = load_waypoints_from_txt(params["waypoints_file"])

    def get_global_path(self):
        return self._waypoints
