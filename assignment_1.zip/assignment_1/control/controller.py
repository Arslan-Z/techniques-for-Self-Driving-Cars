# Copyright (c) # Copyright (c) 2018-2020 CVC.
# This work is licensed under the terms of the MIT license.
# For a copy, see <https://opensource.org/licenses/MIT>.  

from collections import deque
from typing import Union
import math
from sdc.car import Car
import numpy as np
import carla
from sdc.utility import *

from pyilqr.costs import CompositeCost, QuadraticCost
from pyilqr.example_costs import SetpointTrackingCost, PolylineTrackingCost, Polyline
from pyilqr.example_dynamics import UnicycleDynamics
from pyilqr.ocp import OptimalControlProblem
from pyilqr.ilqr import ILQRSolver
from pyilqr.strategies import AbstractStrategy, OpenLoopStrategy, FunctionStrategy


class AbstractController:
    """
    Controller Class 
    """

    def __init__(self, vehicle: Car, params):
        """
        Constructor method.
        :param vehicle: actor to apply to local planner logic onto
        :param params: All the controller related parameters
        """

        self.max_brake = params["control"]["max_brake"]
        self.max_throttle = params["control"]["max_throttle"]
        self.max_steer = params["control"]["max_steering"]
        self.L = params["model"]["L"]
        self.dt = params["sampling_time"]

        self._vehicle = vehicle
        self.past_steering = self._vehicle.get_control().steer

    def compute_control(self, target_velocity_kmph, waypoints):
        """
    	Computes one step of control
        :param target_velocity_kmph: desired vehicle velocity in kmph
        :param waypoints: local trajectory waypoints
        :return: control command for the vehicle.
    	"""
        # target waypoint reached.
        if len(waypoints) < 4:
            return carla.VehicleControl(0, 0, brake=1.0)

        target_velocity_ms = target_velocity_kmph / 3.6

        current_steering, acceleration = self.compute_steering_and_acceleration(
            target_velocity_ms, waypoints
        )

        # Set limits
        control = carla.VehicleControl()
        if acceleration >= 0.0:
            control.throttle = min(acceleration, self.max_throttle)
            control.brake = 0.0
        else:
            control.throttle = 0.0
            control.brake = min(abs(acceleration), self.max_brake)

        if current_steering >= 0:
            steering = min(self.max_steer, current_steering)
        else:
            steering = max(-self.max_steer, current_steering)

        control.steer = steering
        control.hand_brake = False
        control.manual_gear_shift = False
        self.past_steering = steering

        return control

    def compute_steering_and_acceleration(self, target_velocity_ms, waypoints):
        raise NotImplementedError("Controller is not specified!")


class DecomposedController(AbstractController):
    """
    DecomposedController is the combination of two controllers
    (lateral and longitudinal) to perform the low level control a vehicle from client side.
    The longitudinal control is a PID controller, whereas the lateral controller can be 
    chosen from a PID controller, Pure Pursuit Contoller or a Stanley Controller.
    """

    def __init__(self, vehicle: Car, params):
        """
        Constructor method.
        :param vehicle: actor to apply to local planner logic onto
        :param params: All the controller related parameters
        """
        super().__init__(vehicle, params)

        # Longitudinal
        args_longitudinal = params["control"]["longitudinal"]["pid"]
        self._lon_controller = PIDLongitudinalController(
            self._vehicle, self.dt, **args_longitudinal
        )

        # Lateral
        lateral_strategy = params["control"]["strategy"]
        args_lateral = params["control"]["lateral"][lateral_strategy]
        if lateral_strategy == "stanley":
            self._lat_controller = StanleyLateralController(
                self._vehicle, **args_lateral
            )
        elif lateral_strategy == "pure-pursuit":
            self._lat_controller = PurePursuitLateralController(
                self._vehicle, self.L, **args_lateral
            )
        else:
            self._lat_controller = PIDLateralController(
                self._vehicle, self.dt, **args_lateral
            )

    def compute_steering_and_acceleration(self, target_velocity_ms, waypoints):
        """
        Computes one step of control invoking both lateral and longitudinal
        :param target_velocity_ms: desired vehicle velocity in m/s
        :param waypoints: local trajectory waypoints
        :return: control command for the vehicle.
        """
        current_steering = self._lat_controller.run_step(waypoints)
        acceleration = self._lon_controller.run_step(target_velocity_ms)

        # Steering regulation: changes cannot happen abruptly, can't steer too much.
        if current_steering > self.past_steering + 0.1:
            current_steering = self.past_steering + 0.1
        elif current_steering < self.past_steering - 0.1:
            current_steering = self.past_steering - 0.1
        return current_steering, acceleration


class PIDLongitudinalController:
    """
    PIDLongitudinalController implements longitudinal control using a PID.
    """

    def __init__(self, vehicle, dt, K_P, K_D, K_I):
        """
      Constructor method.

          :param vehicle: actor to apply to local planner logic onto
          :param dt: time differential in seconds
          :param K_P: Proportional term
          :param K_D: Differential term
          :param K_I: Integral term
      """

        self._vehicle = vehicle
        self._dt = dt
        self._k_p = K_P
        self._k_d = K_D
        self._k_i = K_I
        self._error_buffer = deque(maxlen=10)

    def run_step(self, target_velocity_ms, debug=False):
        """
    Execute one step of longitudinal control to reach a given target velocity.

        :param target_velocity_ms: target velocity in m/s
        :param debug: boolean for debugging
        :return: throttle control
    """
        current_velocity_ms = get_velocity_ms(self._vehicle)

        if debug:
            print("Current velocity = {}".format(current_velocity_ms))

        return self._pid_control(target_velocity_ms, current_velocity_ms)

    def _pid_control(self, target_velocity_ms, current_velocity_ms):
        """
        Estimate the throttle/brake of the vehicle based on the PID equations

            :param target_velocity_ms:  target velocity in m/s
            :param current_velocity_ms: current velocity of the vehicle in m/s
            :return: throttle/brake control
        """
        #######################################################################
        ################## TODO: IMPLEMENT LONGITUDINAL PID CONTROL HERE ######
        #######################################################################

        return 0.0


class PIDLateralController:
    """
    PIDLateralController implements lateral control using a PID.
    """

    def __init__(self, vehicle, dt, K_P, K_D, K_I):
        """
        Constructor method.

            :param vehicle: actor to apply to local planner logic onto
            :param dt: time differential in seconds
            :param K_P: Proportional term
            :param K_D: Differential term
            :param K_I: Integral term
        """
        self._vehicle = vehicle
        self._dt = dt
        self._k_p = K_P
        self._k_d = K_D
        self._k_i = K_I
        self._e_buffer = deque(maxlen=10)

    def run_step(self, waypoints):
        """
        Execute one step of lateral control to steer
        the vehicle towards a certain waypoin.

            :param waypoint: target waypoint
            :return: steering control in the range [-1, 1] where:
            -1 maximum steering to left
            +1 maximum steering to right
        """
        return self._pid_control(waypoints, self._vehicle.get_transform())

    def _get_heading_error(self, waypoints, vehicle_yaw):
        waypoint_delta_x = waypoints[1][0] - waypoints[0][0]
        waypoint_delta_y = waypoints[1][1] - waypoints[0][1]
        waypoint_heading = np.arctan2(waypoint_delta_y, waypoint_delta_x)
        heading_error_mod = divmod((waypoint_heading - vehicle_yaw), np.pi)[1]
        if heading_error_mod > np.pi / 2 and heading_error_mod < np.pi:
            heading_error_mod -= np.pi
        return heading_error_mod

    def _get_steering_direction(self, v1, v2):
        cross_prod = v1[0] * v2[1] - v1[1] * v2[0]
        if cross_prod >= 0:
            return -1
        return 1

    def _pid_control(self, waypoints, vehicle_transform):
        """
        Estimate the steering angle of the vehicle based on the PID equations

            :param waypoints: local waypoints
            :param vehicle_transform: current transform of the vehicle
            :return: steering control in the range [-1, 1]
        """
        #######################################################################
        ################## TODO: IMPLEMENT LATERAL PID CONTROL HERE ###########
        #######################################################################
        return 0


class StanleyLateralController:
    """
      StanleyLateralController implements lateral control using the stanley controller.
    """

    def __init__(self, vehicle, K_cte):
        self._vehicle = vehicle
        self._k_cte = K_cte

    def run_step(self, waypoints):
        return self._stanley_control(waypoints, self._vehicle.get_transform())

    def _get_heading_error(self, waypoints, vehicle_yaw):
        waypoint_delta_x = waypoints[1][0] - waypoints[0][0]
        waypoint_delta_y = waypoints[1][1] - waypoints[0][1]
        waypoint_heading = np.arctan2(waypoint_delta_y, waypoint_delta_x)
        heading_error_mod = divmod((waypoint_heading - vehicle_yaw), np.pi)[1]
        if heading_error_mod > np.pi / 2 and heading_error_mod < np.pi:
            heading_error_mod -= np.pi
        return heading_error_mod

    def _get_steering_direction(self, v1, v2):
        cross_prod = v1[0] * v2[1] - v1[1] * v2[0]
        if cross_prod >= 0:
            return -1
        return 1

    def _get_cte_heading_error(self, vel, waypoints):
        nearest_waypoint, ind_nearest = get_nearest_waypoint(self._vehicle, waypoints)
        nearest_distance = compute_distance_to_waypoint(self._vehicle, nearest_waypoint)
        proportional_cte_error = self._k_cte * nearest_distance
        cte_heading_error = np.arctan2(proportional_cte_error, vel)
        cte_heading_error_mod = divmod(cte_heading_error, np.pi)[1]
        if cte_heading_error_mod > np.pi / 2 and cte_heading_error_mod < np.pi:
            cte_heading_error_mod -= np.pi
        return cte_heading_error_mod

    def _stanley_control(self, waypoints, vehicle_transform):
        """
        :param waypoint: list of waypoints
        :param vehicle_transform: current transform of the vehicle
        :return: steering control in the range [-1, 1]
        """
        #######################################################################
        ################## TODO: IMPLEMENT STANLEY CONTROL HERE ###############
        #######################################################################
        return 0.0


class PurePursuitLateralController:
    def __init__(self, vehicle, L, ld, K_pp):
        self._vehicle = vehicle
        self._L = L
        self._ld = ld
        self._k_pp = K_pp

    def run_step(self, waypoints):
        return self._pure_pursuit_control(waypoints, self._vehicle.get_transform())

    def _get_goal_waypoint_index(self, vehicle, waypoints, lookahead_dist):
        for i in range(len(waypoints)):
            dist = compute_distance_to_waypoint(vehicle, waypoints[i])
            if dist >= lookahead_dist:
                return max(0, i)
        return len(waypoints) - 1

    def _get_steering_direction(self, v1, v2):
        cross_prod = v1[0] * v2[1] - v1[1] * v2[0]
        if cross_prod >= 0:
            return -1
        return 1

    def _pure_pursuit_control(self, waypoints, vehicle_transform):
        """
        :param waypoints: list of waypoints
        :param vehicle_transform: current transform of the vehicle
        :return: steering control in the range [-1, 1]
        """
        #######################################################################
        ################## TODO: IMPLEMENT PURE-PURSUIT CONTROL HERE ##########
        #######################################################################
        return 0.0


class ModelPredictiveController(AbstractController):
    """
    Receding horizon controller using an iterative LQR solver. At each iteration, the nonlinear optimal control problem is solved with local linear-quadratic approximations.
    """

    def __init__(self, vehicle: Car, params):
        """
        Constructor method.
        :param vehicle: actor to apply to local planner logic onto
        :param params: All the controller related parameters
        """
        super().__init__(vehicle, params)
        self.dynamics = UnicycleDynamics(self.dt)
        self.prediction_horizon = 20
        self._initial_strategy = None
        self.reset_initial_strategy(self._initial_strategy)

    def reset_initial_strategy(self, initial_strategy: Union[AbstractStrategy, None]):
        if initial_strategy is None:
            initial_strategy = FunctionStrategy(
                lambda x, t: np.zeros(self.dynamics.dims[1])
            )
        object.__setattr__(self, "_initial_strategy", initial_strategy)

    def compute_steering_and_acceleration(self, target_velocity_ms, waypoints):
        """
        Computes steering and acceleration
        :param target_velocity_ms: desired vehicle velocity in m/s
        :param waypoints: local trajectory waypoints
        :return: control command for the vehicle.
        """
        
        #######################################################################
        ################## TODO: IMPLEMENT MPC CONTROL HERE ###################
        #######################################################################
        steering = 0.0
        acceleration = 0.0
        return steering, acceleration
